# Downloads - MOPA — Medical Oncology Prior Authorization v0.1.1-snapshot-080926

## Downloads

### NPM Package

Install the Oncology Guideline and Coverage Authorization (MOPA) IG package using the FHIR package manager:

```
## Using the Firely terminal or FHIR-compatible installer
fhir install hl7.fhir.us.codex-mopa@current

```

### Downloadable Artifacts

* [Full IG (zip)](full-ig.zip)
* [NPM Package](package.tgz)
* [Definitions (JSON)](definitions.json.zip)
* [Definitions (XML)](definitions.xml.zip)
* [Examples (JSON)](examples.json.zip)

### Patient Bundle for Review

See [Patient Bundle Review](patient-bundle-review.md) for the contents and provenance of the supplied Terán breast cancer transaction Bundle.

* [Terán Breast Cancer — Cleaned R4 Bundle (JSON)](Bundle-teran-breast-cancer-r4-clean.json)

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.us.codex-mopa.r4)](../package.r4.tgz) and [R4B (hl7.fhir.us.codex-mopa.r4b)](../package.r4b.tgz) are available.































*There are no Global profiles defined*

