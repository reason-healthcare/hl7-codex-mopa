# 324d4f70-205b-60cc-6b1e-13ab57e5fded - MOPA — Medical Oncology Prior Authorization v0.1.1-snapshot-080926

## Example Claim: 324d4f70-205b-60cc-6b1e-13ab57e5fded

**status**: Active

**type**: Professional

**use**: Claim

**patient**: [Julia241 Julia241 Terán294](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-a081-24b98a0f139e)

**billablePeriod**: 2025-06-02 22:05:30-0500 --> 2025-06-02 22:20:30-0500

**created**: 2025-06-02 22:20:30-0500

**provider**: `CHILDRENS MEDICAL CARE INC`

**priority**: Normal

**facility**: `CHILDRENS MEDICAL CARE INC`

### SupportingInfos

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Sequence** | **Category** | **Value[x]** |
| * | 1 | Information | [Immunization: status = completed; vaccineCode = Influenza, split virus, trivalent, PF; occurrence[x] = 2025-06-02 22:05:30-0500; primarySource = true](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-0ffb-080f18161ad7) |

### Insurances

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Sequence** | **Focal** | **Coverage** |
| * | 1 | true | Medicare |

> **item****sequence**: 1**productOrService**: General examination of patient (procedure)**encounter**: [Encounter: identifier = https://github.com/synthetichealth/synthea#324d4f70-205b-60cc-ea9d-c861c301dc37 (use: official, ); status = finished; class = ambulatory (ActCode#AMB); type = General examination of patient (procedure); period = 2025-06-02 22:05:30-0500 --> 2025-06-02 22:20:30-0500](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-ea9d-c861c301dc37)

> **item****sequence**: 2**informationSequence**: 1**productOrService**: Influenza, split virus, trivalent, PF

### Nets

| | | |
| :--- | :--- | :--- |
| - | **Value** | **Currency** |
| * | 136 | United States dollar |


### Totals

| | | |
| :--- | :--- | :--- |
| - | **Value** | **Currency** |
| * | 299.63 | United States dollar |



## Resource Content

```json
{
  "resourceType" : "Claim",
  "id" : "324d4f70-205b-60cc-6b1e-13ab57e5fded",
  "status" : "active",
  "type" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/claim-type",
      "code" : "professional"
    }]
  },
  "use" : "claim",
  "patient" : {
    "reference" : "urn:uuid:324d4f70-205b-60cc-a081-24b98a0f139e",
    "display" : "Julia241 Julia241 Terán294"
  },
  "billablePeriod" : {
    "start" : "2025-06-02T22:05:30-05:00",
    "end" : "2025-06-02T22:20:30-05:00"
  },
  "created" : "2025-06-02T22:20:30-05:00",
  "provider" : {
    "reference" : "Organization?identifier=https://github.com/synthetichealth/synthea|74c32b72-16fa-3913-8df2-10e1b22d1bd7",
    "display" : "CHILDRENS MEDICAL CARE INC"
  },
  "priority" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/processpriority",
      "code" : "normal"
    }]
  },
  "facility" : {
    "reference" : "Location?identifier=https://github.com/synthetichealth/synthea|8d33f2d1-09d6-3578-9fb4-779d57023b3e",
    "display" : "CHILDRENS MEDICAL CARE INC"
  },
  "supportingInfo" : [{
    "sequence" : 1,
    "category" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/claiminformationcategory",
        "code" : "info"
      }]
    },
    "valueReference" : {
      "reference" : "urn:uuid:324d4f70-205b-60cc-0ffb-080f18161ad7"
    }
  }],
  "insurance" : [{
    "sequence" : 1,
    "focal" : true,
    "coverage" : {
      "display" : "Medicare"
    }
  }],
  "item" : [{
    "sequence" : 1,
    "productOrService" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "162673000",
        "display" : "General examination of patient (procedure)"
      }],
      "text" : "General examination of patient (procedure)"
    },
    "encounter" : [{
      "reference" : "urn:uuid:324d4f70-205b-60cc-ea9d-c861c301dc37"
    }]
  },
  {
    "sequence" : 2,
    "informationSequence" : [1],
    "productOrService" : {
      "coding" : [{
        "system" : "http://hl7.org/fhir/sid/cvx",
        "code" : "140",
        "display" : "Influenza, split virus, trivalent, PF"
      }],
      "text" : "Influenza, split virus, trivalent, PF"
    },
    "net" : {
      "value" : 136,
      "currency" : "USD"
    }
  }],
  "total" : {
    "value" : 299.63,
    "currency" : "USD"
  }
}

```
