# e51ade29-614f-a989-be73-2619339f43f0 - MOPA — Medical Oncology Prior Authorization v0.1.1-snapshot-080926

## Example DocumentReference: e51ade29-614f-a989-be73-2619339f43f0

Structured data from this resource. The JSON and XML tabs provide the complete FHIR representation.

* Clinical context: Identifiers
  * **Encounter:** [Encounter: identifier = https://github.com/synthetichealth/synthea#324d4f70-205b-60cc-9d5c-9755ae6ec44b (use: official, ); status = finished; class = ambulatory (ActCode#AMB); type = Postoperative follow-up visit (procedure); period = 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500; reasonCode = Malignant neoplasm of breast (disorder)](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-9d5c-9755ae6ec44b)**Period:** 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500: [Uniform Resource Identifier (URI)](http://terminology.hl7.org/6.2.0/NamingSystem-uri.html)/urn:uuid:a77df40e-86a5-5115-a578-3e01c3807c1e
* Clinical context: Status
  * **Encounter:** [Encounter: identifier = https://github.com/synthetichealth/synthea#324d4f70-205b-60cc-9d5c-9755ae6ec44b (use: official, ); status = finished; class = ambulatory (ActCode#AMB); type = Postoperative follow-up visit (procedure); period = 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500; reasonCode = Malignant neoplasm of breast (disorder)](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-9d5c-9755ae6ec44b)**Period:** 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500: Superseded
* Clinical context: Document type
  * **Encounter:** [Encounter: identifier = https://github.com/synthetichealth/synthea#324d4f70-205b-60cc-9d5c-9755ae6ec44b (use: official, ); status = finished; class = ambulatory (ActCode#AMB); type = Postoperative follow-up visit (procedure); period = 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500; reasonCode = Malignant neoplasm of breast (disorder)](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-9d5c-9755ae6ec44b)**Period:** 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500: History and physical note
* Clinical context: Categories
  * **Encounter:** [Encounter: identifier = https://github.com/synthetichealth/synthea#324d4f70-205b-60cc-9d5c-9755ae6ec44b (use: official, ); status = finished; class = ambulatory (ActCode#AMB); type = Postoperative follow-up visit (procedure); period = 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500; reasonCode = Malignant neoplasm of breast (disorder)](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-9d5c-9755ae6ec44b)**Period:** 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500: Nexis Health
* Clinical context: Subject
  * **Encounter:** [Encounter: identifier = https://github.com/synthetichealth/synthea#324d4f70-205b-60cc-9d5c-9755ae6ec44b (use: official, ); status = finished; class = ambulatory (ActCode#AMB); type = Postoperative follow-up visit (procedure); period = 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500; reasonCode = Malignant neoplasm of breast (disorder)](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-9d5c-9755ae6ec44b)**Period:** 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500: [Julia Julia Terán (official) Female, DoB: 1942-11-30 ( https://github.com/synthetichealth/synthea#324d4f70-205b-60cc-a081-24b98a0f139e)](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-a081-24b98a0f139e)
* Clinical context: Document date
  * **Encounter:** [Encounter: identifier = https://github.com/synthetichealth/synthea#324d4f70-205b-60cc-9d5c-9755ae6ec44b (use: official, ); status = finished; class = ambulatory (ActCode#AMB); type = Postoperative follow-up visit (procedure); period = 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500; reasonCode = Malignant neoplasm of breast (disorder)](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-9d5c-9755ae6ec44b)**Period:** 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500: 2024-04-17 23:42:26-0500
* Clinical context: Authors
  * **Encounter:** [Encounter: identifier = https://github.com/synthetichealth/synthea#324d4f70-205b-60cc-9d5c-9755ae6ec44b (use: official, ); status = finished; class = ambulatory (ActCode#AMB); type = Postoperative follow-up visit (procedure); period = 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500; reasonCode = Malignant neoplasm of breast (disorder)](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-9d5c-9755ae6ec44b)**Period:** 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500: `Dr. Bertram Pyle`
* Clinical context: Custodian
  * **Encounter:** [Encounter: identifier = https://github.com/synthetichealth/synthea#324d4f70-205b-60cc-9d5c-9755ae6ec44b (use: official, ); status = finished; class = ambulatory (ActCode#AMB); type = Postoperative follow-up visit (procedure); period = 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500; reasonCode = Malignant neoplasm of breast (disorder)](Bundle-teran-breast-cancer-r4-clean.md#urn-uuid-324d4f70-205b-60cc-9d5c-9755ae6ec44b)**Period:** 2024-04-17 23:42:26-0500 --> 2024-04-18 00:21:07-0500: `OPEN ACCESS VASCULAR ACCESS CENTER INC`

### Attachments


```

2024-04-17

# Chief Complaint
No complaints.

# History of Present Illness
Julia241 Julia241 is a 81 year-old hispanic white female.

# Social History
Patient is single. Patient quit smoking at age 16.
 Patient identifies as heterosexual.

Patient comes from a middle socioeconomic background.
 Patient has completed some college courses.
Patient currently has Medicare.

# Allergies
No Known Allergies.

# Medications
No Active Medications.

# Assessment and Plan



## Plan

The following procedures were conducted:
- physical examination, complete (procedure)

```

**Content format:** [IHE Format Code set for use with Document Sharing: urn:ihe:iti:xds:2017:mimeTypeSufficient](https://profiles.ihe.net/fhir/ihe.formatcode.fhir/1.1.0/CodeSystem-formatcode.html#formatcode-urn.58ihe.58iti.58xds.582017.58mimeTypeSufficient) (mimeType Sufficient)



## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "e51ade29-614f-a989-be73-2619339f43f0",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/us/core/StructureDefinition/us-core-documentreference"]
  },
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:uuid:a77df40e-86a5-5115-a578-3e01c3807c1e"
  }],
  "status" : "superseded",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "34117-2",
      "display" : "History and physical note"
    },
    {
      "system" : "http://loinc.org",
      "code" : "51847-2",
      "display" : "Evaluation + Plan note"
    }]
  },
  "category" : [{
    "coding" : [{
      "system" : "http://hl7.org/fhir/us/core/CodeSystem/us-core-documentreference-category",
      "code" : "clinical-note",
      "display" : "Nexis Health"
    }]
  }],
  "subject" : {
    "reference" : "urn:uuid:324d4f70-205b-60cc-a081-24b98a0f139e"
  },
  "date" : "2024-04-17T23:42:26.471-05:00",
  "author" : [{
    "reference" : "Practitioner?identifier=http://hl7.org/fhir/sid/us-npi|9999968495",
    "display" : "Dr. Bertram Pyle"
  }],
  "custodian" : {
    "reference" : "Organization?identifier=https://github.com/synthetichealth/synthea|22b012cf-d62c-3354-ad66-c36d080d1512",
    "display" : "OPEN ACCESS VASCULAR ACCESS CENTER INC"
  },
  "content" : [{
    "attachment" : {
      "contentType" : "text/plain; charset=utf-8",
      "data" : "CjIwMjQtMDQtMTcKCiMgQ2hpZWYgQ29tcGxhaW50Ck5vIGNvbXBsYWludHMuCgojIEhpc3Rvcnkgb2YgUHJlc2VudCBJbGxuZXNzCkp1bGlhMjQxIEp1bGlhMjQxIGlzIGEgODEgeWVhci1vbGQgaGlzcGFuaWMgd2hpdGUgZmVtYWxlLgoKIyBTb2NpYWwgSGlzdG9yeQpQYXRpZW50IGlzIHNpbmdsZS4gUGF0aWVudCBxdWl0IHNtb2tpbmcgYXQgYWdlIDE2LgogUGF0aWVudCBpZGVudGlmaWVzIGFzIGhldGVyb3NleHVhbC4KClBhdGllbnQgY29tZXMgZnJvbSBhIG1pZGRsZSBzb2Npb2Vjb25vbWljIGJhY2tncm91bmQuCiBQYXRpZW50IGhhcyBjb21wbGV0ZWQgc29tZSBjb2xsZWdlIGNvdXJzZXMuClBhdGllbnQgY3VycmVudGx5IGhhcyBNZWRpY2FyZS4KCiMgQWxsZXJnaWVzCk5vIEtub3duIEFsbGVyZ2llcy4KCiMgTWVkaWNhdGlvbnMKTm8gQWN0aXZlIE1lZGljYXRpb25zLgoKIyBBc3Nlc3NtZW50IGFuZCBQbGFuCgoKCiMjIFBsYW4KClRoZSBmb2xsb3dpbmcgcHJvY2VkdXJlcyB3ZXJlIGNvbmR1Y3RlZDoKLSBwaHlzaWNhbCBleGFtaW5hdGlvbiwgY29tcGxldGUgKHByb2NlZHVyZSkK"
    },
    "format" : {
      "system" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
      "code" : "urn:ihe:iti:xds:2017:mimeTypeSufficient",
      "display" : "mimeType Sufficient"
    }
  }],
  "context" : {
    "encounter" : [{
      "reference" : "urn:uuid:324d4f70-205b-60cc-9d5c-9755ae6ec44b"
    }],
    "period" : {
      "start" : "2024-04-17T23:42:26-05:00",
      "end" : "2024-04-18T00:21:07-05:00"
    }
  }
}

```
